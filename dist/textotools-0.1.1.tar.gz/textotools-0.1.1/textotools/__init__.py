# __init__.py
from .main import abrir_arquivo, contar_palavras, contar_caracteres, contar_palavras_iguais, substituir_substring, remover_palavra, compress_texto, decompress_texto 